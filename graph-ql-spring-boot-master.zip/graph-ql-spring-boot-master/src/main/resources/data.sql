
INSERT INTO Address (addid,country,city,FLAT) VALUES ('13', 'india', 'delhi','r20');
INSERT INTO Address (addid,country,city,FLAT) VALUES ('14', 'USA', 'sandeigo','ad20');
INSERT INTO Address (addid,country,city,FLAT) VALUES ('15', 'China', 'chez','a221');
INSERT INTO Employee (id, name, age,addid) VALUES ('1', 'employee1', 23,'13');
INSERT INTO Employee (id, name, age,addid) VALUES ('3', 'employee1', 53,'14');
INSERT INTO Employee (id, name, age,addid) VALUES ('2', 'employee1', 22,'15');